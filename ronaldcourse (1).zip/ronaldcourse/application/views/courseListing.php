<!-- listing start-->
		<div class="inner_banner">
			<div class="inner_overlay"></div>
			<div class="container">
				<div class="row">
					<div class="col-12 col-sm-12 col-md-12 col-lg-12">
						<div class="page-title-heading">
                            <h2 class="title">COURSES LIST</h2>
                            <ul>
                                <li><a href="<?php echo base_url(); ?>">Home</a></li>
                                <li>Courses List</li>
                            </ul>
                        </div>
					</div>
				</div>
			</div>
		</div>
		<!-- courses -->
	<div class="container mt-5 mb-5">  
	 <div class="register_outer">
                <span class="register_loader"></span>
            </div>
		<div class="row">
		   
			<div id="courseListData"></div>
	</div>
	<div id='pagination'></div>
</div>
	<!-- listing end-->
<script src="<?php echo base_url(); ?>assets/js/courseListing.js"></script>
	<script type="text/javascript">
        var baseURL = "<?php echo base_url(); ?>";
        var base_url = "<?php echo base_url(); ?>";
    </script>
</body>
</html>

