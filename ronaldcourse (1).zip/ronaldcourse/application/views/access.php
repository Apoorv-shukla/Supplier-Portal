<div class="content-wrapper">    
    <section class="content-header">
      <h1>
        Access Denied
        <small>You are not authorize user to use this</small>
      </h1>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-xs-12 text-center">
                <img src="<?php echo base_url() ?>assets/images/access.png" alt="Access Denied Image" />
            </div>
        </div>
    </section>
</div>