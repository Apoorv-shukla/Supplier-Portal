// JavaScript Document
$(document).ready(function() {
  $(".skitter-large").skitter({
	  label:false,
	  dots:false,
	  interval: 4000,
  });
});
